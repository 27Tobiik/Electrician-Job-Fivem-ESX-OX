fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name '27electricianjob'
author '27'
version '3.1.0-pro'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/locales.lua',
    'shared/shared.lua'
}

client_scripts {
    'client/config.lua',
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory'
}