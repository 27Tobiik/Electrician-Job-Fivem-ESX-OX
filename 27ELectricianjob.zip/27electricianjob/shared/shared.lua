function _L(key)
  local t = Locales[Config.Locale or 'cs']
  return (t and t[key]) or key
end

function VPRINT(...)
  if Config.Debug and Config.Debug.Prints then
    print('[27electricianjob]', ...)
  end
end