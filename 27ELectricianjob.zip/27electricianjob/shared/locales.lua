Locales = Locales or {}

Locales['cs'] = {
  npc_title = 'Mistr elektrikář',
  start = 'Začít práci',
  submit = 'Odevzdat práci',
  cancel = 'Ukončit práci dřív',
  debug_reset = 'DEBUG: Reset práce',

  starting = 'Zahajuji…',
  started = 'Práce zahájena. Jeď na první zakázku.',
  already_running = 'Už máš rozjetou práci.',
  no_run = 'Nemáš aktivní brigádu. Vezmi si ji u NPC.',
  not_finished = 'Ještě nemáš hotovo 5/5.',
  submitted = 'Práce odevzdána. Díky!',
  cancelled = 'Práce zrušena.',
  vehicle_failed = 'Nepodařilo se spawnout služební auto.',
  register_failed = 'Nepodařilo se zaregistrovat služební auto.',
  no_space = 'Nemáš místo v inventáři (váha).',
  need_items = 'Chybí ti brigádní vybavení.',
  cooldown = 'Chvilku počkej.',
  too_far = 'Jsi moc daleko.',
  must_be_driver = 'Musíš sedět jako řidič ve služebním autě.',
  wrong_vehicle = 'Musíš být v přiděleném služebním autě.',

  fix_label = 'Opravit elektrickou skříňku',
  working = 'Opravuji…',
  failed = 'Nepovedlo se, zkus to znovu.',
  next_job = 'Hotovo! Pokračuj na další zakázku.',
  return_to_npc = 'Hotovo 5/5! Vrať se k NPC a odevzdej práci.',
  reset_done = 'Reset hotový. Zkus Start znovu.',
}