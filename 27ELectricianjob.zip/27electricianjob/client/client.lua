-- 27electricianjob PRO client (COORDS ONLY)
-- Uses: ox_lib, ox_target
-- Vehicle spawn client-side + server register netId
-- Fix interaction only via dynamic ox_target sphere zone at current job coords

local jobActive = false
local runDone = false

local vehNetId = nil
local vehLocal = 0

local blip = nil
local currentZoneId = nil

local idx = 0
local total = 0

local function notify(t, msg)
  lib.notify({ type = t or 'inform', description = msg })
end

local function setBlip(coords, text)
  if blip then
    RemoveBlip(blip)
    blip = nil
  end

  blip = AddBlipForCoord(coords.x, coords.y, coords.z)
  SetBlipSprite(blip, 354)
  SetBlipColour(blip, 5)
  SetBlipScale(blip, 0.85)
  SetBlipRoute(blip, true)

  BeginTextCommandSetBlipName('STRING')
  AddTextComponentString(text or 'Zakázka')
  EndTextCommandSetBlipName(blip)
end

local function clearBlip()
  if blip then
    RemoveBlip(blip)
    blip = nil
  end
end

local function removeFixZone()
  if currentZoneId then
    exports.ox_target:removeZone(currentZoneId)
    currentZoneId = nil
  end
end

local function loadAnim(dict)
  RequestAnimDict(dict)
  while not HasAnimDictLoaded(dict) do Wait(0) end
end

local function attachProp(model, bone, pos, rot)
  lib.requestModel(model)
  local ped = PlayerPedId()
  local obj = CreateObject(model, GetEntityCoords(ped), true, true, false)
  AttachEntityToEntity(
    obj,
    ped,
    GetPedBoneIndex(ped, bone),
    pos.x, pos.y, pos.z,
    rot.x, rot.y, rot.z,
    true, true, false, true, 1, true
  )
  return obj
end

local function spawnWorkVehicle(modelName, spawn)
  local model = joaat(modelName)
  lib.requestModel(model)

  local veh = CreateVehicle(model, spawn.x, spawn.y, spawn.z, spawn.w, true, false)
  if veh == 0 then return 0, 0 end

  SetVehicleOnGroundProperly(veh)
  SetEntityAsMissionEntity(veh, true, true)

  local plate = (Config.Vehicle.platePrefix or 'ELEC') .. tostring(math.random(10, 99))
  SetVehicleNumberPlateText(veh, plate)

  -- lock for others (safe variant: no global lock that breaks exit)
  if Config.Vehicle.lockForOthers then
    SetVehicleDoorsLocked(veh, 2) -- locked
    SetVehicleDoorsLockedForPlayer(veh, PlayerId(), false) -- allow me
    -- DO NOT: SetVehicleDoorsLockedForAllPlayers(veh, true) (can break exit)
  end

  local netId = NetworkGetNetworkIdFromEntity(veh)
  local tries = 0
  while (netId == 0) and tries < 100 do
    Wait(0)
    netId = NetworkGetNetworkIdFromEntity(veh)
    tries += 1
  end

  TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
  return veh, netId
end

local function deleteWorkVehicle()
  if vehLocal ~= 0 and DoesEntityExist(vehLocal) then
    DeleteVehicle(vehLocal)
  end
  vehLocal = 0
  vehNetId = nil
end

local function cleanupClientState()
  removeFixZone()
  clearBlip()
  deleteWorkVehicle()

  jobActive = false
  runDone = false
  idx = 0
  total = 0
end

local function doFixAtCoords(coords)
  if not jobActive then
    notify('error', _L('no_run'))
    return
  end

  if runDone then
    notify('inform', _L('return_to_npc'))
    return
  end

  local ped = PlayerPedId()
  local pcoords = GetEntityCoords(ped)
  local target = vec3(coords.x, coords.y, coords.z)

  if #(pcoords - target) > 3.0 then
    notify('error', _L('too_far'))
    return
  end

  -- Request server token (coords-only -> pass netId 0)
  local res = lib.callback.await('27electricianjob:requestToken', false, 0, { x = coords.x, y = coords.y, z = coords.z })
  if not res or not res.ok then
    notify('error', _L(res and res.err or 'failed'))
    return
  end

  local ok = lib.skillCheck(Config.Work.Skillcheck.Difficulties, Config.Work.Skillcheck.Inputs)
  if not ok then
    notify('error', _L('failed'))
    return
  end

  loadAnim(Config.Work.Anim.Dict)
  local prop = attachProp(
    Config.Work.Anim.PropModel,
    Config.Work.Anim.PropBone,
    Config.Work.Anim.PropOffset,
    Config.Work.Anim.PropRot
  )

  local done = lib.progressBar({
    duration = Config.Work.ProgressMs,
    label = _L('working'),
    useWhileDead = false,
    canCancel = true,
    disable = { move = true, car = true, combat = true },
    anim = { dict = Config.Work.Anim.Dict, clip = Config.Work.Anim.Clip },
  })

  ClearPedTasks(ped)
  if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
  if not done then return end

  -- Finish fix (coords-only -> netId 0)
  TriggerServerEvent('27electricianjob:finishFix', { token = res.token, netId = 0 })

  -- prevent double-use until server sends next job / done
  removeFixZone()
end

local function createFixZone(coords)
  removeFixZone()

  currentZoneId = exports.ox_target:addSphereZone({
    coords = vec3(coords.x, coords.y, coords.z),
    radius = 2.0,
    debug = false,
    options = {
      {
        name = '27electricianjob_fix',
        icon = 'fa-solid fa-wrench',
        label = _L('fix_label'),
        onSelect = function()
          doFixAtCoords(coords)
        end,
      }
    }
  })
end

local function openMenu()
  local options = {
    {
      title = _L('start'),
      icon = 'fa-solid fa-play',
      onSelect = function()
        notify('inform', _L('starting'))

        local res = lib.callback.await('27electricianjob:start', false)
        if not res or not res.ok then
          notify('error', _L(res and res.err or 'vehicle_failed'))
          return
        end

        -- spawn work vehicle (client) + register on server
        local veh, netId = spawnWorkVehicle(res.model, res.spawn)
        if netId == 0 then
          notify('error', _L('vehicle_failed'))
          return
        end

        local reg = lib.callback.await('27electricianjob:registerVehicle', false, netId)
        if not reg or not reg.ok then
          DeleteVehicle(veh)
          notify('error', _L('register_failed'))
          return
        end

        vehLocal = veh
        vehNetId = netId

        jobActive = true
        runDone = false
        idx = res.idx
        total = res.total

        setBlip(res.loc, ('Zakázka (%d/%d)'):format(idx, total))
        createFixZone(res.loc)

        notify('success', _L('started'))
      end
    },
    {
      title = _L('submit'),
      icon = 'fa-solid fa-check',
      onSelect = function()
        local res = lib.callback.await('27electricianjob:submit', false)
        if not res or not res.ok then
          notify('error', _L(res and res.err or 'not_finished'))
          return
        end

        cleanupClientState()
        notify('success', _L('submitted'))
      end
    },
    {
      title = _L('cancel'),
      icon = 'fa-solid fa-xmark',
      onSelect = function()
        local res = lib.callback.await('27electricianjob:cancel', false)
        if not res or not res.ok then
          notify('error', _L(res and res.err or 'no_run'))
          return
        end

        cleanupClientState()
        notify('inform', _L('cancelled'))
      end
    },
  }

  if Config.Debug and Config.Debug.ResetOption then
    table.insert(options, {
      title = _L('debug_reset'),
      icon = 'fa-solid fa-bug',
      onSelect = function()
        local r = lib.callback.await('27electricianjob:forceReset', false)
        if r and r.ok then
          cleanupClientState()
          notify('success', _L('reset_done'))
        end
      end
    })
  end

  lib.registerContext({
    id = '27electricianjob:npc',
    title = _L('npc_title'),
    options = options
  })

  lib.showContext('27electricianjob:npc')
end

local function spawnNPC()
  local model = joaat(Config.NPC.model)
  lib.requestModel(model)

  local c = Config.NPC.coords
  local npc = CreatePed(0, model, c.x, c.y, c.z - 1.0, c.w, false, true)
  SetEntityInvincible(npc, true)
  SetBlockingOfNonTemporaryEvents(npc, true)
  FreezeEntityPosition(npc, true)

  if Config.NPC.scenario then
    TaskStartScenarioInPlace(npc, Config.NPC.scenario, 0, true)
  end

  exports.ox_target:addLocalEntity(npc, {
    {
      name = '27electricianjob_npc',
      icon = 'fa-solid fa-bolt',
      label = _L('npc_title'),
      distance = 2.0,
      onSelect = openMenu
    }
  })

  if Config.NPC.blip and Config.NPC.blip.enabled then
    local b = AddBlipForCoord(c.x, c.y, c.z)
    SetBlipSprite(b, Config.NPC.blip.sprite)
    SetBlipScale(b, Config.NPC.blip.scale)
    SetBlipColour(b, Config.NPC.blip.colour)
    SetBlipAsShortRange(b, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.NPC.blip.name)
    EndTextCommandSetBlipName(b)
  end
end

-- Server -> next job coords
RegisterNetEvent('27electricianjob:nextJob', function(nextLoc, newIdx, newTotal)
  jobActive = true
  runDone = false
  idx = newIdx
  total = newTotal

  setBlip(nextLoc, ('Zakázka (%d/%d)'):format(idx, total))
  createFixZone(nextLoc)

  notify('success', _L('next_job'))
end)

-- Server -> run done (5/5)
RegisterNetEvent('27electricianjob:runDone', function()
  runDone = true
  jobActive = true

  removeFixZone()

  local c = Config.NPC.coords
  setBlip({ x = c.x, y = c.y, z = c.z }, _L('npc_title'))

  notify('success', _L('return_to_npc'))
end)

CreateThread(function()
  spawnNPC()
end)