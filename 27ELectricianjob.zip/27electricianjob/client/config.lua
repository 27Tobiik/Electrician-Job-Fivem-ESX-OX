Config = {}

Config.Locale = 'cs'
Config.JobsPerRun = 5

Config.NPC = {
  model = 's_m_m_dockwork_01',
  coords = vec4(723.0237, -1069.5273, 23.0624, 102.8676),
  scenario = 'WORLD_HUMAN_CLIPBOARD',
  blip = { enabled = true, sprite = 354, scale = 0.85, colour = 5, name = 'Elektrikářská brigáda' }
}


Config.Vehicle = {
  model = 'burrito3',
  spawn = vec4(716.6792, -1079.0305, 22.0862, 88.0044),
  platePrefix = 'ELEC',
  requireDriver = false,       
  lockForOthers = true,       
  deleteOnCancel = true,
}
Config.Vehicle.lockForOthers = false

Config.Items = {
  Toolkit = 'ej_toolkit',
  Wire = 'ej_wire',
  Fuse = 'ej_fuse',
}

Config.Consume = { Wire = 1, Fuse = 1 }

Config.Rewards = {
  MoneyItem = 'money',        
  MinPerJob = 120,
  MaxPerJob = 220,
}

Config.Work = {
  ProgressMs = 6500,
  Skillcheck = {
    Difficulties = { 'easy', 'easy', 'medium' },
    Inputs = { 'W', 'A', 'S', 'D' },
  },
  Anim = {
    Dict = 'amb@world_human_welding@male@base',
    Clip = 'base',
    PropModel = `prop_weld_torch`,
    PropBone = 57005,
    PropOffset = vec3(0.12, 0.02, -0.02),
    PropRot = vec3(-80.0, 0.0, 10.0),
  }
}

Config.BoxModels = {
  `prop_elecbox_10`,
  `prop_elecbox_11`,
  `prop_elecbox_12`,
  `prop_elecbox_14`,
  `prop_elecbox_15`,
}

Config.JobLocations = {
  vec4(-272.2049, -774.2879, 32.2556, 57.3586),
  vec4(42.9249, -668.4209, 31.7460, 161.4692),
  vec4(489.2245, -1010.3110, 27.9402, 115.3621),
  vec4(959.3873, -1003.2759, 39.9981, 207.5621),
  vec4(180.4727, -406.3855, 41.4029, 249.8658),
  vec4(-2.6740, -1379.0538, 29.3489, 85.9263),
  vec4(-108.8858, -895.0293, 29.2588, 250.7486),
}

Config.Security = {
  CooldownSeconds = 6,
  TargetDistance = 2.2,       
  EntityDistance = 6.0,       
  ContractRadius = 55.0,      
  TokenTTL = 25,              
  FlagOnSuspicious = true,
  AnticheatExport = nil,      
}

Config.Debug = {
  ResetOption = false,         
  Prints = false
}

