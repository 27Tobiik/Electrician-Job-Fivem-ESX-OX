local runs = {}    -- [src] = { locs, idx, state, vehNetId, lastAction }
local tokens = {}  -- [src] = { token, exp, netId }

local function flag(src, reason)
  if not (Config.Security and Config.Security.FlagOnSuspicious) then return end
  print(('[27electricianjob] Suspicious src=%s reason=%s'):format(src, reason))
  local expName = Config.Security.AnticheatExport
  if expName then
    pcall(function()
      exports[expName]:flag(src, ('27electricianjob:%s'):format(reason))
    end)
  end
end

local function cooldownOk(src)
  local run = runs[src]
  if not run then return true end
  local cd = Config.Security.CooldownSeconds or 0
  local last = run.lastAction or 0
  return (os.time() - last) >= cd
end

local function setCooldown(src)
  if runs[src] then runs[src].lastAction = os.time() end
end

local function shuffleCopy(t)
  local a = {}
  for i=1,#t do a[i]=t[i] end
  for i=#a,2,-1 do
    local j = math.random(i)
    a[i], a[j] = a[j], a[i]
  end
  return a
end

local function pickLocations(n)
  local pool = shuffleCopy(Config.JobLocations)
  local out = {}
  for i=1, math.min(n, #pool) do out[#out+1] = pool[i] end
  return out
end

local function reqCounts()
  local jobs = Config.JobsPerRun or 5
  return {
    toolkit = 1,
    wire = (Config.Consume.Wire or 0) * jobs,
    fuse = (Config.Consume.Fuse or 0) * jobs,
  }
end

local function cleanupItems(src)
  local inv = exports.ox_inventory
  local w = inv:Search(src, 'count', Config.Items.Wire) or 0
  local f = inv:Search(src, 'count', Config.Items.Fuse) or 0
  local t = inv:Search(src, 'count', Config.Items.Toolkit) or 0
  if w > 0 then inv:RemoveItem(src, Config.Items.Wire, w) end
  if f > 0 then inv:RemoveItem(src, Config.Items.Fuse, f) end
  if t > 0 then inv:RemoveItem(src, Config.Items.Toolkit, t) end
end

local function giveItems(src)
  local inv = exports.ox_inventory
  local r = reqCounts()

  cleanupItems(src)

  -- pokud chceš úplně vypnout kontrolu váhy, odkomentuj tyto 3 řádky a smaž CanCarry:
  -- inv:AddItem(src, Config.Items.Toolkit, r.toolkit)
  -- if r.wire > 0 then inv:AddItem(src, Config.Items.Wire, r.wire) end
  -- if r.fuse > 0 then inv:AddItem(src, Config.Items.Fuse, r.fuse) end
  -- return true

  if not inv:CanCarryItem(src, Config.Items.Toolkit, r.toolkit) then return false end
  if r.wire > 0 and not inv:CanCarryItem(src, Config.Items.Wire, r.wire) then return false end
  if r.fuse > 0 and not inv:CanCarryItem(src, Config.Items.Fuse, r.fuse) then return false end

  inv:AddItem(src, Config.Items.Toolkit, r.toolkit)
  if r.wire > 0 then inv:AddItem(src, Config.Items.Wire, r.wire) end
  if r.fuse > 0 then inv:AddItem(src, Config.Items.Fuse, r.fuse) end
  return true
end

local function hasItems(src)
  local inv = exports.ox_inventory
  local toolkit = inv:Search(src, 'count', Config.Items.Toolkit) or 0
  local wire = inv:Search(src, 'count', Config.Items.Wire) or 0
  local fuse = inv:Search(src, 'count', Config.Items.Fuse) or 0
  return toolkit >= 1 and wire >= (Config.Consume.Wire or 0) and fuse >= (Config.Consume.Fuse or 0)
end

local function consumeItems(src)
  local inv = exports.ox_inventory
  if (Config.Consume.Wire or 0) > 0 then inv:RemoveItem(src, Config.Items.Wire, Config.Consume.Wire) end
  if (Config.Consume.Fuse or 0) > 0 then inv:RemoveItem(src, Config.Items.Fuse, Config.Consume.Fuse) end
end

local function reward(src)
  local inv = exports.ox_inventory
  local total = 0
  for i=1, (Config.JobsPerRun or 5) do
    total += math.random(Config.Rewards.MinPerJob, Config.Rewards.MaxPerJob)
  end
  inv:AddItem(src, Config.Rewards.MoneyItem, total)
end

local function ped(src) return GetPlayerPed(src) end
local function vec3FromVec4(v) return vec3(v.x, v.y, v.z) end

-- DEBUG reset
lib.callback.register('27electricianjob:forceReset', function(src)
  cleanupItems(src)
  runs[src] = nil
  tokens[src] = nil
  return { ok=true }
end)

-- START run (auto se spawnuje na klientovi)
lib.callback.register('27electricianjob:start', function(src)
  VPRINT('START called by', src)

  if runs[src] then
    return { ok=false, err='already_running' }
  end

  local okItems = giveItems(src)
  if not okItems then
    return { ok=false, err='no_space' }
  end

  local locs = pickLocations(Config.JobsPerRun or 5)
  if #locs < (Config.JobsPerRun or 5) then
    cleanupItems(src)
    return { ok=false, err='vehicle_failed' }
  end

  runs[src] = {
    locs = locs,
    idx = 1,
    state = 'active',
    vehNetId = nil,
    lastAction = 0
  }

  local first = locs[1]
  return {
    ok=true,
    model = Config.Vehicle.model,
    spawn = { x=Config.Vehicle.spawn.x, y=Config.Vehicle.spawn.y, z=Config.Vehicle.spawn.z, w=Config.Vehicle.spawn.w },
    loc = { x=first.x, y=first.y, z=first.z },
    idx = 1,
    total = #locs
  }
end)

-- Registrace auta (netId) od klienta
lib.callback.register('27electricianjob:registerVehicle', function(src, vehNetId)
  local run = runs[src]
  if not run or run.state ~= 'active' then
    return { ok=false }
  end

  if type(vehNetId) ~= 'number' or vehNetId <= 0 then
    flag(src, 'bad_vehicle_netid')
    return { ok=false }
  end

  run.vehNetId = vehNetId
  runs[src] = run
  return { ok=true }
end)

-- CANCEL
lib.callback.register('27electricianjob:cancel', function(src)
  local run = runs[src]
  if not run then return { ok=false, err='no_run' } end

  cleanupItems(src)
  runs[src] = nil
  tokens[src] = nil
  return { ok=true }
end)

-- SUBMIT
lib.callback.register('27electricianjob:submit', function(src)
  local run = runs[src]
  if not run then return { ok=false, err='no_run' } end
  if run.state ~= 'done' then return { ok=false, err='not_finished' } end

  reward(src)
  cleanupItems(src)

  runs[src] = nil
  tokens[src] = nil
  return { ok=true }
end)

-- Request token pro opravu
lib.callback.register('27electricianjob:requestToken', function(src, boxNetId, boxCoords)
  local run = runs[src]
  if not run or run.state ~= 'active' then return { ok=false, err='no_run' } end
  if not cooldownOk(src) then return { ok=false, err='cooldown' } end
  if not hasItems(src) then return { ok=false, err='need_items' } end

  -- musí být zaregistrované auto
  if not run.vehNetId then
    flag(src, 'no_vehicle_registered')
    return { ok=false, err='wrong_vehicle' }
  end

  local p = ped(src)
  if not p or p == 0 then
    flag(src, 'no_ped')
    return { ok=false, err='too_far' }
  end

  -- vehicle + driver check
  if Config.Vehicle.requireDriver then
    local v = GetVehiclePedIsIn(p, false)
    if v == 0 then return { ok=false, err='wrong_vehicle' } end
    if GetPedInVehicleSeat(v, -1) ~= p then return { ok=false, err='must_be_driver' } end

    local vNet = NetworkGetNetworkIdFromEntity(v)
    if vNet ~= run.vehNetId then
      flag(src, 'wrong_vehicle')
      return { ok=false, err='wrong_vehicle' }
    end
  end

  -- radius check k aktuální lokaci
  local current = run.locs[run.idx]
  local goal = vec3FromVec4(current)
  local pcoords = GetEntityCoords(p)
  if #(pcoords - goal) > (Config.Security.ContractRadius or 55.0) then
    flag(src, 'outside_contract_radius')
    return { ok=false, err='too_far' }
  end

  -- vzdálenost k entitě
  if type(boxCoords) == 'table' and boxCoords.x then
    local ecoords = vec3(boxCoords.x, boxCoords.y, boxCoords.z)
    if #(pcoords - ecoords) > (Config.Security.EntityDistance or 6.0) then
      flag(src, 'entity_too_far')
      return { ok=false, err='too_far' }
    end
  end

  local token = tostring(math.random(100000, 999999)) .. tostring(os.time())
  tokens[src] = { token=token, exp=os.time() + (Config.Security.TokenTTL or 25), netId=boxNetId }

  return { ok=true, token=token }
end)

-- Dokončení opravy
RegisterNetEvent('27electricianjob:finishFix', function(data)
  local src = source
  if type(data) ~= 'table' then flag(src, 'bad_payload'); return end

  local run = runs[src]
  if not run or run.state ~= 'active' then flag(src, 'finish_without_run'); return end

  local t = tokens[src]
  tokens[src] = nil
  if not t then flag(src, 'no_token'); return end
  if t.token ~= data.token or t.netId ~= data.netId then flag(src, 'token_mismatch'); return end
  if t.exp < os.time() then flag(src, 'token_expired'); return end

  if not cooldownOk(src) then return end
  setCooldown(src)

  if not hasItems(src) then flag(src, 'finish_without_items'); return end
  consumeItems(src)

  run.idx += 1
  if run.idx > #run.locs then
    run.state = 'done'
    runs[src] = run
    TriggerClientEvent('27electricianjob:runDone', src)
    return
  end

  runs[src] = run
  local nextLoc = run.locs[run.idx]
  TriggerClientEvent('27electricianjob:nextJob', src, { x=nextLoc.x, y=nextLoc.y, z=nextLoc.z }, run.idx, #run.locs)
end)

AddEventHandler('playerDropped', function()
  local src = source
  cleanupItems(src)
  runs[src] = nil
  tokens[src] = nil
end)